#Helpful package for custom transformers to use in sklearn pipelines

##Dataframe Transformers List
1. DataFrameSelector
2. DFObjectSelector
3. DFFeatureUnion
4. DFImputer
5. DFImputerMostFrequent
6. DFOrdinalEncoder
7. DFStandardScaler